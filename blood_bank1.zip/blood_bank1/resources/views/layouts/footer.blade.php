@section('styles')
    <link rel="stylesheet" href="{{ asset('css/footer.css') }}">
@endsection

<footer class="footer">
    <div class="container">
        <p>© 2024 جميع الحقوق محفوظة - إدارة بنك الدم</p>
    </div>
</footer>

@extends('layouts.dashboard-template')
@section('content')
    إعدادات 
@endsection

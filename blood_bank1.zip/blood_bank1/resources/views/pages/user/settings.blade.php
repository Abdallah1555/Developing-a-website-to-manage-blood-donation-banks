@extends('layouts.dashboard-template-user')
@section('content')
    إعدادات 
@endsection

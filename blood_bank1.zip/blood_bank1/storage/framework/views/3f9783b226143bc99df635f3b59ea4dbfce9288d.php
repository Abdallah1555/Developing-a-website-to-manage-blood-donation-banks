
<?php $__env->startSection('content'); ?>
    <section class="recent-requests">
        <h2 class="title">طلبات التبرع بالدم التي قمت بها</h2>
        <a class="btn-excel" href="<?php echo e(route('dashboarduser.requestsBlood')); ?>">اطلب دم</a>
        <a class="btn-pdf" href="<?php echo e(route('dashboarduser.donateBlood')); ?>"> تبرع الآن</a>
        <table id="centersTable" class="display">
            <thead>
                <tr>
                    <th>رقم الطلب</th>
                    <th>نوع فصيلة الدم </th>
                    <th>كمية الدم </th>
                    <th>تاريخ الطلب</th>
                    <th>الحالة</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $count = 1;
                ?>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($count++); ?></td>
                        <td><?php echo e($request->BloodType); ?></td>
                        <td><?php echo e($request->Quantity); ?></td>
                        <td><?php echo e($request->RequestDate); ?></td>
                        <td><?php echo e($request->Status); ?></td>

                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    <script>
        $(document).ready(function() {
                $('#centersTable').DataTable({
                    "language": {
                        "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json"
                    },
                    dom: 'Bfrtip',
                    buttons: [

                        {
                            extend: 'print',
                            text: 'طباعة',
                            className: 'btn-print'

                        }
                    ]
                })
            }

        )
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/requests.blade.php ENDPATH**/ ?>
<header class="header">
    <div class="container">
        <h1 class="headertitle">
            <img src="<?php echo e(asset('images/logo.png')); ?>" alt="logo" class="logo">

            دمك حياة
        </h1>
        <nav class="navbar">
            <div class="nav">

                <a href="/">الرئيسية</a>
                <a href="<?php echo e(route('views.about')); ?>">عن النظام</a>
                <a href="<?php echo e(route('views.contact')); ?>">تواصل معنا</a>
            </div>
            <div class="login">

                <a href="<?php echo e(route('login')); ?>" class="">تسجيل دخول</a>
                <a href="<?php echo e(route('roles')); ?>" class=""> انشاء حساب</a>
            </div>



        </nav>
    </div>
</header>
<?php /**PATH D:\laravel\blood_bank1\resources\views/layouts/header.blade.php ENDPATH**/ ?>

<?php $__env->startSection('content'); ?>
    <section class="recent-requests">
        <h2 class="title">مراكز التبرع </h2>
        <table id="centersTable" class="display">
            <thead>
                <tr>
                    <th>اسم المركز</th>
                    <th>عنوان المركز</th>
                    <th>رقم الهاتف</th>
                    <th>العمليات </th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $center): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($center->Username); ?></td>
                        <td><?php echo e($center->Address); ?></td>
                        <td><?php echo e($center->ContactNumber); ?></td>
                        <td  class="buttons">
                <a href="" class="btn btn-warning editbtn">تواصل</a>
                <a href="" class="btn btn-danger deletebtn">طلب تبرع</a>
                </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>

    <script>
        $(document).ready(function() {
            $('#centersTable').DataTable({
                "language": {
                    "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json"
                },
                dom: 'Bfrtip',
                buttons: [
                    {
                        extend: 'print',
                        text: 'طباعة',
                        className: 'btn-print'

                    }
                ]
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/bloodbanks.blade.php ENDPATH**/ ?>
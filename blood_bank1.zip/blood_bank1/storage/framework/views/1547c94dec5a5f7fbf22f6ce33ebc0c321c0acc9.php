    
    <?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


  <section class="role-selection">
        <div class="container">
            <h2>اختر نوع حسابك</h2>
            <div class="role-options">
                <a href="<?php echo e(route('register.bloodbank')); ?>" class="role-card">
                    <h3>بنك الدم</h3>
                    <p>إنشاء حساب لبنك الدم</p>
                </a>
                <a href="<?php echo e(route('register.user')); ?>" class="role-card">
                    <h3>مستخدم</h3>
                    <p>إنشاء حساب كمستخدم عادي</p>
                </a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/auth/register/roles.blade.php ENDPATH**/ ?>
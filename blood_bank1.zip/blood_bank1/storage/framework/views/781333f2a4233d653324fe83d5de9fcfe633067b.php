
<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/auth.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="login-section">
    <div class="container">
        <form action="<?php echo e(route('login.post')); ?>" method="POST" class="login-form">
            <?php echo csrf_field(); ?>
            <h2>تسجيل الدخول</h2>
            <?php if(session('success')): ?>
            <p class="alert alert-success "><?php echo e(session('success')); ?></p>
            <?php endif; ?>
            <?php if(session('error')): ?>
            <p class="alert alert-danger "><?php echo e(session('error')); ?></p>
            <?php endif; ?>
            <!-- Email -->
            <div class="form-group">
                <label for="email" >البريد الإلكتروني</label>
                <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="error" style="color:red;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

           


                <div class="form-group">
                    <label for="password" >كلمة المرور</label>
                    <input type="password" id="password" name="password" >
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error" style="color:red;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <a href="<?php echo e(route('password.request')); ?>" class="create_account_tag">هل نسيت كلمة السر؟</a>

                </div>

                <a href="<?php echo e(route('roles')); ?>" class="create_account_tag"> انشاء حساب </a>

                <!-- Submit Button -->
                <button type="submit" class="btn-primary">تسجيل الدخول</button>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/auth/login/login.blade.php ENDPATH**/ ?>
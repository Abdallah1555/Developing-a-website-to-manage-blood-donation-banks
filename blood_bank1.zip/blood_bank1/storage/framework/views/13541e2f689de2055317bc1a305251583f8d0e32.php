
<?php $__env->startSection('content'); ?>
<section class="recent-requests">
    <h2 class="title">طلبات التبرع بالدم </h2>
    <table id="centersTable" class="display">
        <thead>
            <tr>
                <th>اسم المتقدم</th>
                <th>نوع فصيلة الدم </th>
                <th>كمية الدم </th>
                <th>تاريخ الطلب</th>
                <th>الحالة</th>
                <th>العمليات</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
            <td><?php echo e($request->Username); ?></td>
                <td><?php echo e($request->BloodType); ?></td>
                <td><?php echo e($request->Quantity); ?></td>
                <td><?php echo e($request->RequestDate); ?></td>
                <td><?php echo e($request->Status); ?></td>
                <td>
                <a href="<?php echo e(route('bloodRequest.edit' , $request->id )); ?>" class="btn btn-warning editbtn">Edit</a>
                <a href="#" class="btn btn-danger deletebtn">Delete</a>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</section>
<script>
    $(document).ready(function(){
        $('#centersTable').DataTable({
            "language": {
                "url": "//cdn.datatables.net/plug-ins/1.11.5/i18n/ar.json" 
            },
            dom: 'Bfrtip',
            buttons: [
                
                {
                    extend: 'print',
                    text: 'طباعة',
                                        className: 'btn-print'

                }
            ]
        })
    }

    )
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/admin/requests.blade.php ENDPATH**/ ?>
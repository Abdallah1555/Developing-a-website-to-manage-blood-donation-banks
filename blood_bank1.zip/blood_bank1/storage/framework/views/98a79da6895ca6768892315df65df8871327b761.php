


<?php $__env->startSection('content'); ?>
    <section class="">
        <div class="card-info">



            <div class="user-info">

                <img class="profileImage" src="<?php echo e(asset('storage/' . $userProfile->profile_image)); ?>" alt="profile img">

                <h1 class="fs-2">اهلاً بعودتك <?php echo e($user->Username); ?></h1>
            </div>
            <div>
                <p>1</p>
                <p>تبرعاتك</p>
            </div>

            <div>
                <p>2</p>
                <p>بنوك الدم</p>

            </div>
            <div>
                <p>3</p>
                <p>طلبات التبرع حولك</p>

            </div>

        </div>
        <div class="notification">
            <div class="notifi-header">
                <p class="fs-4">جميع الاشعارات </p>
                <span>0</span>
            </div>
            <div class="body">
                <div>

                    <h1>title</h1>
                    <p>body</p>
                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template-user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/user/dashboard.blade.php ENDPATH**/ ?>
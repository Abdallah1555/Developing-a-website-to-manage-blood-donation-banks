
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/about&contact.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class=" container container-section">
        <div class="contact">
            <h2 class="title">تواصل معنا</h2>
            <p>إذا كان لديك أي أسئلة أو ترغب في المساهمة في مهمتنا، يرجى الاتصال بنا على:</p>
            <p>البريد الإلكتروني: <a href="mailto:info@bloodbank.com">info@bloodbank.com</a></p>
            <p>الهاتف:+970 568491450</p>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/about&contact/contact.blade.php ENDPATH**/ ?>
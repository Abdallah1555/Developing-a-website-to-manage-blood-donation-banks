
<?php $__env->startSection('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('css/forms.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class=" forms">
        <h1 class="title">تعديل بنك دم </h1>
        <?php if(session('success')): ?>
            <div class="sccessmassage">
                <p> done</p>
            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="failemassage">
                <p> faile</p>
            </div>
        <?php endif; ?>
            
        <form action="<?php echo e(route('bloodCenter.update', $user->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="input-group">
                <label for="name">اسم بنك الدم</label>
                <input type="text" placeholder="اسم بنك الدم" class="input" name="Username" id="name" value="<?php echo e(old('name', $user->Username)); ?>">
            </div>
            <div class="input-group">
                <label for="address">عنوان بنك الدم</label>
                <input type="text" placeholder="عنوان بنك الدم" class="input" name="Address" id="address" value="<?php echo e(old('address', $profile->Address)); ?>">
            </div>
            <div class="input-group">
                <label for="phone">رقم الهاتف </label>
                <input type="text" placeholder="رقم الهاتف" class="input" name="ContactNumber" id="phone" value="<?php echo e(old('phone', $profile->ContactNumber)); ?>">
            </div>
            <input type="submit" value="تعديل" class="btn submit">
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard-template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/admin/bloodcenteredit.blade.php ENDPATH**/ ?>


<?php $__env->startSection('content'); ?>
    <section class="profile-step1-section">
        <div class="container w-75">
            <h2 class="w-100 text-end pt-4">الخطوة 1: تحميل صورة الملف الشخصي</h2>

            <form action="<?php echo e(route('profile.post.step1', ['user_id' => $user_id])); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <!-- Profile Image -->
                <div class="form-group">
                    <label for="profile_image" class="w-100 text-end">صورة الملف الشخصي</label>
                    <input type="file" id="profile_image" name="profile_image"  class="text-end">
                    <?php $__errorArgs = ['profile_image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="error" style="color:red;"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Next Button -->
                <button type="submit" class="btn-danger w-25 m-auto">التالي</button>
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laravel\blood_bank1\resources\views/pages/profile/step1.blade.php ENDPATH**/ ?>